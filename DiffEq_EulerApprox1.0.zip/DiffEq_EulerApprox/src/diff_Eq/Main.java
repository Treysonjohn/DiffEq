package diff_Eq;

public class Main {

	public static void main(String[] args) {
		Approximate.setVariables();
		
		System.out.print(Approximate.eulerApprox());
	}

}

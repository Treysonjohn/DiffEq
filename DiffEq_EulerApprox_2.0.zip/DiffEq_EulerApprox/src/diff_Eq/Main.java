package diff_Eq;

public class Main {

	public static void main(String[] args) {
		Approximate.setVariables();
		
		System.out.println("Normal Euler's Method:");
		System.out.println(Approximate.eulerApprox());
		System.out.println("Improved Euler's Method:");
		System.out.println(Approximate.improvedEulerApprox());
		System.out.println("Runga Kutta Method:");
		System.out.println(Approximate.rungeKuttaApprox());
	}

}

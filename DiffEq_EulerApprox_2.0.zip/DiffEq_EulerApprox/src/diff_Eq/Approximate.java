package diff_Eq;

import java.util.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Approximate {
	private static ArrayList<Double> xCheck = new ArrayList<Double>(); //every x value you need the y value at
	private static BigDecimal stepSize = new BigDecimal("0"); //the distance between each euler approx
	private static BigDecimal yInitial = new BigDecimal("0"); //starting y value
	private static BigDecimal xInitial = new BigDecimal("0"); //starting x value
	
	private static ArrayList<Double> yAtX = new ArrayList<Double>();  //every y value at each xChack value
	private static BigDecimal currentY = new BigDecimal("0"); //used in both approx as the y-value at a given point
	private static BigDecimal nextY = new BigDecimal("0");   //used in both approx as the next y-value at a given point

	public static ArrayList<Double> eulerApprox() { //normal euler approx. called after running the variable setup function "setVariables"
		currentY = yInitial;
		int xCheckIndex = 0;
		yAtX.clear();
		
		for(BigDecimal i = new BigDecimal(xInitial.toString()) ; i.doubleValue() <= xCheck.get(xCheck.size()-1); i = i.add(stepSize)) { //loops through every x value from x-initial to the final xCheck
			nextY = currentY.add(derivative(i, currentY).multiply(stepSize));
			
			if(i.doubleValue() == xCheck.get(xCheckIndex)) {
				yAtX.add(xCheckIndex, currentY.doubleValue());
				xCheckIndex++;
			}
			
			currentY = nextY;
		}
		
		return yAtX;
	}
	
	public static ArrayList<Double> improvedEulerApprox() { //improved euler approx. called after running the variable setup function "setVariables"
		currentY = yInitial;
		int xCheckIndex = 0;
		yAtX.clear();
		
		for(BigDecimal i = new BigDecimal(xInitial.toString()) ; i.doubleValue() <= xCheck.get(xCheck.size()-1); i = i.add(stepSize)) { //loops through every x value from x-initial to the final xCheck
			nextY = currentY.add(BigDecimal.valueOf(.5).multiply(stepSize).multiply(derivative(i, currentY).add(derivative(i.add(stepSize),currentY.add(stepSize.multiply(derivative(i,currentY)))))));
			
			if(i.doubleValue() == xCheck.get(xCheckIndex)) {
				yAtX.add(xCheckIndex, currentY.doubleValue());
				xCheckIndex++;
			}
			
			currentY = nextY;
		}
		
		return yAtX;
	}
	
	public static ArrayList<Double> rungeKuttaApprox() { //improved euler approx. called after running the variable setup function "setVariables"
		currentY = yInitial;
		int xCheckIndex = 0;
		yAtX.clear();
		
		for(BigDecimal i = new BigDecimal(xInitial.toString()) ; i.doubleValue() <= xCheck.get(xCheck.size()-1); i = i.add(stepSize)) { //loops through every x value from x-initial to the final xCheck
			BigDecimal k1 = derivative(i, currentY);
			BigDecimal k2 = derivative(i.add(stepSize.multiply(BigDecimal.valueOf(.5))), currentY.add(stepSize.multiply(k1.multiply(BigDecimal.valueOf(.5)))));
			BigDecimal k3 = derivative(i.add(stepSize.multiply(BigDecimal.valueOf(.5))), currentY.add(stepSize.multiply(k2.multiply(BigDecimal.valueOf(.5)))));
			BigDecimal k4 = derivative(i.add(stepSize), currentY.add(stepSize.multiply(k3)));
			BigDecimal kAll = k1.add(k2.multiply(BigDecimal.valueOf(2))).add(k3.multiply(BigDecimal.valueOf(2))).add(k4);
			nextY = currentY.add((BigDecimal.valueOf(1.0).divide(BigDecimal.valueOf(6.0), 100, RoundingMode.HALF_UP)).multiply(stepSize).multiply(kAll));
		
			if(i.doubleValue() == xCheck.get(xCheckIndex)) {
				yAtX.add(xCheckIndex, currentY.doubleValue());
				xCheckIndex++;
			}
			
			currentY = nextY;
		}
		
		return yAtX;
	}
	
	private static BigDecimal derivative(BigDecimal x, BigDecimal y) {
		return BigDecimal.valueOf(.6).subtract(x).add(y); //Edit the value inside the parenthesis!!!!!
	}
	
	public static void setVariables() {
		Scanner input = new Scanner(System.in);
		
		String tempString;
		
		System.out.println("Type every x value you want the approximation of, hitting enter after each one. Type 'Done' and hit enter when finished");
		xCheck.clear();
		while(true) {
			tempString = input.next();
			if(tempString.toLowerCase().equals("done")) {
				break;
			}
			xCheck.add(Double.valueOf(tempString));
		}
		Collections.sort(xCheck);
		
		System.out.println("Enter the starting x value");
		xInitial = BigDecimal.valueOf(input.nextDouble());
		
		System.out.println("Enter the starting y value");
		yInitial = BigDecimal.valueOf(input.nextDouble());
		
		System.out.println("Enter the step size");
		stepSize = BigDecimal.valueOf(input.nextDouble());
		
		input.close();
	}
}
